<?php
session_start();
include 'includes/header.php'; ?>

    <h2>Your Flowers Are Waiting!</h2>
    <p>Explore our amazing selection of flowers and arrangements.</p>
    <!-- Add more content here as needed -->

<?php include 'includes/ footer.php'; ?>
