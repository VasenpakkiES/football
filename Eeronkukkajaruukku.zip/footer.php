<footer>
        <p>&copy; <?php echo date('Y'); ?> Eero Siljanderin Kukka & Ruukkukauppa, 2024. Kaikki oikeudet pidätetään.</p>
        <nav>
            <ul>
            <li><a href="index.php">Home</a></li>
                <li><a href="users/register.php">Register</a></li> <!-- Adjusted path to register -->
                <li><a href="users/login.php">Login</a></li> <!-- Adjusted path to login -->
                <li><a href="users/profile.php">Profile</a></li> <!-- Adjusted path to profile -->
                <li><a href="users/logout.php">Logout</a></li> <!-- Adjusted path to logout -->
                <li><a href="shop.php">Shop</a></li>
                <li><a href="flowers.php">Flowers</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="accessories.php">Accessories</a></li>
                <li><a href="gifts.php">Gifts</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </nav>
    </footer>

    <script src="js/script.js"></script>
</body>
</html>
